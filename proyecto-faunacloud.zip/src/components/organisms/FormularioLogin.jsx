import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { validarEmail, validarClave } from '../../utils/validaciones.js';

export default function FormularioLogin() {
  const navigate = useNavigate(); 
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const [errores, setErrores] = useState({});

  const manejarIngreso = (e) => {
    e.preventDefault(); 

    
    const errorEmail = validarEmail(email);
    const errorClave = validarClave(password);

    
    if (errorEmail || errorClave) {
      setErrores({ email: errorEmail, clave: errorClave });
      return; 
    }

    
    setErrores({});
    navigate('/catalogo'); 
  };

  return (
    <form onSubmit={manejarIngreso} className="p-4 border rounded shadow-sm bg-white mx-auto" style={{maxWidth: '400px', marginTop: '50px'}}>
      <h2 className="mb-4 text-center fw-bold text-primary">Iniciar Sesión</h2>
      
      <div className="mb-3">
        <label className="form-label">Correo Electrónico</label>
        <input 
          type="text" 
          className={`form-control ${errores.email ? 'is-invalid' : ''}`}
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
        />
        {/* Mostramos el error solo si existe */}
        {errores.email && <div className="invalid-feedback">{errores.email}</div>}
      </div>

      <div className="mb-4">
        <label className="form-label">Contraseña</label>
        <input 
          type="password" 
          className={`form-control ${errores.clave ? 'is-invalid' : ''}`}
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
        />
        {errores.clave && <div className="invalid-feedback">{errores.clave}</div>}
      </div>

      <button type="submit" className="btn btn-primary w-100 fw-bold">
        Ingresar a FaunaCloud
      </button>
    </form>
  );
}